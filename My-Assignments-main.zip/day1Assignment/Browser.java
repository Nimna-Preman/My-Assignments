package week1.day1Assignment;

public class Browser {

	public static void main(String[] args) {
		//to print a statement
		System.out.println("This is my Browser");

	}

}
