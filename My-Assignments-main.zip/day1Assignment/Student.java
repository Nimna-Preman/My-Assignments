package week1.day1Assignment;

public class Student {

	public static void main(String[] args) {
		
		// TO declare variables
		
		String Studentname = "Nimna";
		double markscored =98.454;
		int rollno = 15;
		String collegename ="sriram engineering";
		float cgpa = 6.94f;
		
		System.out.println("Student name is"+Studentname);
		System.out.println("mark scored is "+markscored);
				System.out.println(collegename);
				System.out.println(cgpa);
				System.out.println("roll no is"+ rollno);
		

	}

}
